<?php
require_once "includes/conexao.php"; // Assegure-se de que o caminho está correto

// Recupera parâmetros de filtro
$state = $_POST['state'] ?? '';
$city = $_POST['city'] ?? '';
$type = $_POST['type'] ?? '';
$minSalary = $_POST['minSalary'] ?? 0;
$maxSalary = $_POST['maxSalary'] ?? 1000000;
$page = $_POST['page'] ?? 1;

$limit = 10;
$offset = ($page - 1) * $limit;

// Cria a query
$query = "SELECT * FROM tb_vaga WHERE 1=1"; // Adiciona um filtro para evitar problemas com a construção da query

// Filtra por estado e cidade (se fornecido)
if ($state) {
    $query .= " AND localizacao LIKE ?";
    $params[] = "%$state%";
}

if ($city) {
    $query .= " AND localizacao LIKE ?";
    $params[] = "%$city%";
}

$query .= " LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['jobs' => $jobs]);
