<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contato - Busca Jobs</title>
    <!-- Importar o Bootstrap e Font Awesome -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="css/contato.css">
</head>

<body>
    <?php
    require_once "includes/header.php"
    ?>
    <div class="first-part">
        <div class="line-red"></div>
        <h1>Contato</h1>
    </div>

    <div class="info-section">
        <p>Home / Contato</p>
    </div>

    <div class="second-part container">
        <div class="row">
            <div class="col-md-4">
                <i class="fas fa-map-marker-alt icons-height"></i>
                <h2>Endereço</h2>
                <p>Rua Exemplo, 123, Centro, São Paulo, SP - 01000-000</p>
            </div>
            <div class="col-md-4">
                <i class="fas fa-phone-alt icons-height"></i>
                <h2>Contato</h2>
                <p>E-mail: contato@buscajobs.com.br<br>Telefone: +55 11 1234-5678</p>
            </div>
            <div class="col-md-4">
                <i class="fas fa-share-alt icons-height"></i>
                <h2>Redes Sociais</h2>
                <div class="social-icons">
                    <a href="https://www.facebook.com/BuscaJobs" class="fab fa-facebook-f"></a>
                    <a href="https://www.instagram.com/BuscaJobs" class="fab fa-instagram"></a>
                    <a href="https://www.linkedin.com/company/buscajobs" class="fab fa-linkedin-in"></a>
                </div>
            </div>
        </div>
    </div>

    <div class="third-part">
        <h1>Fale Conosco</h1>
        <p>Se você tem alguma dúvida ou deseja saber mais sobre nossas vagas e serviços, entre<br> em contato conosco! Estamos aqui para ajudá-lo a encontrar a oportunidade certa.</p>
    </div>

    <div class="fourth-part">
        <div class="form-container">
            <form>
                <input type="text" placeholder="Nome" required>
                <input type="email" placeholder="Email" required>
                <input type="text" placeholder="Assunto" required>
                <textarea placeholder="Mensagem" required></textarea>
                <button type="submit">Enviar</button>
            </form>
        </div>
        <div class="map-container">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.0731212519686!2d-46.5476090248303!3d-23.56581717879671!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce5d4f40f4621f%3A0xa42dc1aebb9da597!2sCasa%20de%20Apostas%20Formosa!5e0!3m2!1spt-BR!2sbr!4v1725024024669!5m2!1spt-BR!2sbr" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>
    <?php
    require_once "includes/footer.php"
    ?>

    <!-- Scripts do Bootstrap e Font Awesome -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
