<?php
session_start();
require_once 'includes/conexao.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['logado']) || $_SESSION['logado'] !== true) {
    header('Location: login.php');
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["id_vaga"])) {
        $id_vaga = $_POST["id_vaga"];
        $email = $_SESSION['email']; // Obtendo o email do usuário autenticado
        $nome = $_SESSION['nome']; // Obtendo o nome do usuário

        // Verifica se o usuário existe no banco de dados
        $query = "SELECT id_usuario FROM tb_usuario WHERE email_usuario = '$email'";
        $result = mysqli_query($conn, $query);
        $usuario = mysqli_fetch_assoc($result);

        if ($usuario) {
            $id_usuario = $usuario['id_usuario'];

            // Inserir a candidatura na tabela de candidaturas
            $sql_candidatura = "INSERT INTO tb_candidatura (id_usuario, id_vaga) VALUES ('$id_usuario', '$id_vaga')";
            if (mysqli_query($conn, $sql_candidatura)) {
                $_SESSION['mensagem_sucesso'] = "Candidatura realizada com sucesso!";
                header('Location: servico.php');
                exit();
            } else {
                $_SESSION['mensagem_erro'] = "Erro ao realizar candidatura: " . mysqli_error($conn);
                header('Location: servico.php');
                exit();
            }
        } else {
            // Caso não exista (não deve acontecer se o login for bem-sucedido)
            $_SESSION['mensagem_erro'] = "Usuário não encontrado.";
            header('Location: servico.php');
            exit();
        }
    } else {
        $_SESSION['mensagem_erro'] = "ID da vaga não foi fornecido.";
        header('Location: servico.php');
        exit();
    }
}
?>
