<?php
require_once "conexao.php";

header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);
$userId = $data['userId'];
$jobId = $data['jobId'];

if ($userId && $jobId) {
    $stmt = $conn->prepare("INSERT INTO tb_candidatura (id_usuario, id_vaga) VALUES (?, ?)");
    $stmt->bind_param("ii", $userId, $jobId);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'titulo' => $jobId]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Erro ao inserir a candidatura.']);
    }
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Dados inválidos.']);
}

$conn->close();
?>
