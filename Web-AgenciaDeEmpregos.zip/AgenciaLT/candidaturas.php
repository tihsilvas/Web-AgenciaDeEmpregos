<?php
session_start();
require_once "includes/conexao.php";

// Verifica se o usuário está logado e é administrador
if (!isset($_SESSION['logado']) || $_SESSION['logado'] !== true) {
    header("Location: login.php");
    exit();
}

// Processa o formulário para criar nova vaga
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifica se os campos estão preenchidos
    if (!empty($_POST["titulo"]) && !empty($_POST["localizacao"]) && !empty($_POST["descricao"])) {
        $titulo = mysqli_real_escape_string($conn, $_POST["titulo"]);
        $localizacao = mysqli_real_escape_string($conn, $_POST["localizacao"]);
        $descricao = mysqli_real_escape_string($conn, $_POST["descricao"]);

        // Insere a nova vaga no banco de dados
        $insert_query = "INSERT INTO tb_vaga (titulo, localizacao, descricao) VALUES ('$titulo', '$localizacao', '$descricao')";
        
        if (mysqli_query($conn, $insert_query)) {
            $_SESSION['mensagem_sucesso'] = "Vaga criada com sucesso!";
        } else {
            $_SESSION['mensagem_erro'] = "Erro ao criar vaga: " . mysqli_error($conn);
        }

        // Redireciona para a página de candidaturas
        header("Location: servico1.php");
        exit();
    } else {
        $_SESSION['mensagem_erro'] = "Todos os campos são obrigatórios!";
    }
}

mysqli_close($conn);
?>
