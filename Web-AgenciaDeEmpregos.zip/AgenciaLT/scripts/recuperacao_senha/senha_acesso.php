<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/recuperar.css">
    <title>Recuperação de Senha</title>
</head>
<body>
    <div class="container">
        <h2>Segue-se abaixo sua Senha de Acesso.</h2><br>
        <?php
         session_start();
         require_once "../../includes/conexao.php";
         require_once "../../criptografia/descriptografar.php";
         require_once "../../criptografia/criptografar.php";
         
        if(isset($_SESSION['email'])) {
            // Recuperar o email da sessão
            $emailhash = $_SESSION['email'];

            // Consultar o banco de dados para obter a senha correspondente ao email
            require_once "../../includes/conexao.php";
            $query = "SELECT * FROM tb_usuario";
            $result = mysqli_query($conn, $query);

            if ($result) {
                $senha_descriptografada = null;
                while ($row = mysqli_fetch_assoc($result)) {
                    $email_descriptografado = decryptData($row['email_usuario'], $key);
                    if ($emailhash === $email_descriptografado) {
                        $senha_descriptografada = decryptData($row['senha_usuario'], $key);
                        break;
                    }
                }

                if ($senha_descriptografada !== null && $senha_descriptografada !== '') {
                    echo "<p>A senha do usuário é: $senha_descriptografada</p>";
                    echo "<p>Você será redirecionado em 10 segundos.</p>";
                    header("Refresh: 10; url=../../login.php");
                    exit();
                } else {
                    echo "<p>Email encontrado, mas a senha não pôde ser recuperada.</p>";
                }
            } else {
                echo "<p>Erro na consulta ao banco de dados.</p>";
            }
        } else {
            echo "<p>Email não fornecido.</p>";
        }
        ?>
    </div>
</body>
</html>
