<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/recuperar.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Inserir Código de Verificação</title>
</head>
<body>
    <a href="inserir_email.html" class="back-icon"><i class="fas fa-arrow-left"></i></a>
    <div class="form-wrapper">
        <h1 class="titulo">Código de Verificação</h1>
        <form action="verificar_codigo.php" method="POST">
            <label for="txt_codigo">Informe o código de verificação:</label><br>
            <input type="text" id="txt_codigo" name="txt_codigo" required><br><br>
            <input type="submit" value="Verificar Código">
            <input type="hidden" name="email" value="<?php echo $_SESSION['email']; ?>">
        </form>
    </div>
</body>
</html>
