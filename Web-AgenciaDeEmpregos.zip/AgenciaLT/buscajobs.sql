CREATE DATABASE IF NOT EXISTS `bd_buscajobs`;
USE `bd_buscajobs`;

-- Cria a tabela de usuários
CREATE TABLE IF NOT EXISTS `tb_usuario` (
    `id_usuario` INT AUTO_INCREMENT PRIMARY KEY NOT NULL COMMENT 'Identificador único do usuário',
    `email_usuario` VARCHAR(256) NOT NULL UNIQUE COMMENT 'Email do usuário (deve ser único)',
    `senha_usuario` VARCHAR(256) NOT NULL COMMENT 'Senha do usuário (armazenada criptografada)',
    `nome_usuario` VARCHAR(50) NOT NULL COMMENT 'Nome completo do usuário',
    `descricao` VARCHAR(255) DEFAULT NULL COMMENT 'Descrição adicional sobre o usuário',
    `foto_usuario` VARCHAR(255) DEFAULT NULL COMMENT 'URL da foto do usuário',
    `tipo_usuario` BOOLEAN NOT NULL DEFAULT 0 COMMENT 'Indica se o usuário é PJ (1) ou CPF (0)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- Cria a tabela de vagas
CREATE TABLE IF NOT EXISTS `tb_vaga` (
    `id_vaga` INT AUTO_INCREMENT PRIMARY KEY NOT NULL COMMENT 'Identificador único da vaga',
    `titulo` VARCHAR(255) NOT NULL COMMENT 'Título da vaga',
    `localizacao` VARCHAR(255) NOT NULL COMMENT 'Localização onde a vaga está disponível',
    `descricao` TEXT NOT NULL COMMENT 'Descrição detalhada da vaga',
    `imagem` VARCHAR(255) DEFAULT NULL COMMENT 'URL da imagem associada à vaga'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `tb_candidatura` (
    `id_candidatura` INT AUTO_INCREMENT PRIMARY KEY NOT NULL COMMENT 'Identificador único da candidatura',
    `id_usuario` INT NOT NULL COMMENT 'Identificador do usuário que se candidatou',
    `id_vaga` INT NOT NULL COMMENT 'Identificador da vaga para a qual o usuário se candidatou',
    `data_candidatura` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Data da candidatura',
    FOREIGN KEY (`id_usuario`) REFERENCES `tb_usuario`(`id_usuario`),
    FOREIGN KEY (`id_vaga`) REFERENCES `tb_vaga`(`id_vaga`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- Insere dados de exemplo na tabela de vagas
INSERT INTO `tb_vaga` (`titulo`, `localizacao`, `descricao`, `imagem`) VALUES
('Desenvolvedor Front-End', 'São Paulo, SP', 'Trabalhe com uma equipe dinâmica e desenvolva aplicações inovadoras. Requer conhecimento em HTML, CSS, JavaScript e frameworks modernos.', 'developer.png'),
('Analista de Sistemas', 'Rio de Janeiro, RJ', 'Análise e desenvolvimento de sistemas com foco em inovação tecnológica. Experiência em análise de requisitos e documentação.', 'analyst.png'),
('Gerente de Projetos', 'Belo Horizonte, MG', 'Gerenciar projetos de alta complexidade e coordenar equipes multifuncionais. Habilidade em gerenciamento de projetos e comunicação eficaz são essenciais.', 'manager.png'),
('Especialista em Marketing', 'Porto Alegre, RS', 'Desenvolvimento de estratégias de marketing e análise de mercado. Experiência em campanhas digitais e SEO é desejada.', 'marketer.png'),
('Consultor de Vendas', 'Curitiba, PR', 'Consultoria em vendas, identificação de oportunidades e desenvolvimento de estratégias. Experiência em vendas e habilidades de negociação são fundamentais.', 'sales.png');
