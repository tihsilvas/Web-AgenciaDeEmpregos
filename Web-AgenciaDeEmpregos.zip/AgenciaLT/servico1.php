<?php
session_start();
require_once "includes/conexao.php";

// Verifica se o usuário está logado e é administrador
if (!isset($_SESSION['logado']) || $_SESSION['logado'] !== true) {
    header("Location: login.php");
    exit();
}

// Consulta as candidaturas
$candidaturas = [];
$query = "SELECT c.id_candidatura, u.nome_usuario, v.titulo, c.data_candidatura 
          FROM tb_candidatura c 
          JOIN tb_usuario u ON c.id_usuario = u.id_usuario 
          JOIN tb_vaga v ON c.id_vaga = v.id_vaga";
$result = mysqli_query($conn, $query);

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $candidaturas[] = $row;
    }
}

// Processa o formulário para criar nova vaga
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['titulo'], $_POST['localizacao'], $_POST['descricao'])) {
    $titulo = mysqli_real_escape_string($conn, $_POST['titulo']);
    $localizacao = mysqli_real_escape_string($conn, $_POST['localizacao']);
    $descricao = mysqli_real_escape_string($conn, $_POST['descricao']);
    
    $insert_query = "INSERT INTO tb_vaga (titulo, localizacao, descricao) VALUES ('$titulo', '$localizacao', '$descricao')";
    if (mysqli_query($conn, $insert_query)) {
        $_SESSION['mensagem_sucesso'] = "Vaga criada com sucesso!";
    } else {
        $_SESSION['mensagem_erro'] = "Erro ao criar vaga: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultas e Criação de Vagas</title>
    <link rel="stylesheet" href="css/servico1.css">
</head>
<body class="servico1">
    <?php require_once "includes/header.php"; ?>

    <div class="content">        
        <div id="notification">
            <?php if (isset($_SESSION['mensagem_sucesso'])): ?>
                <div class="alert success">
                    <?php
                        echo $_SESSION['mensagem_sucesso'];
                        unset($_SESSION['mensagem_sucesso']);
                    ?>
                </div>
            <?php elseif (isset($_SESSION['mensagem_erro'])): ?>
                <div class="alert error">
                    <?php
                        echo $_SESSION['mensagem_erro'];
                        unset($_SESSION['mensagem_erro']);
                    ?>
                </div>
            <?php endif; ?>
        </div>

        <h2>Candidatos às Vagas</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome do Candidato</th>
                    <th>Título da Vaga</th>
                    <th>Data da Candidatura</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($candidaturas as $candidatura): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($candidatura['id_candidatura']); ?></td>
                        <td><?php echo htmlspecialchars($candidatura['nome_usuario']); ?></td>
                        <td><?php echo htmlspecialchars($candidatura['titulo']); ?></td>
                        <td><?php echo htmlspecialchars($candidatura['data_candidatura']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <h2>Criar Nova Vaga</h2>
        <form action="candidaturas.php" method="POST">
            <label for="titulo">Título:</label>
            <input type="text" id="titulo" name="titulo" required>

            <label for="localizacao">Localização:</label>
            <input type="text" id="localizacao" name="localizacao" required>

            <label for="descricao">Descrição:</label>
            <textarea id="descricao" name="descricao" required></textarea>

            <button type="submit">Criar Vaga</button>
        </form>
    </div>
    
    <?php require_once "includes/footer.php"; ?>
</body>
</html>
