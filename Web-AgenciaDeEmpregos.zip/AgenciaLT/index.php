<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Busca Jobs - Conectando Oportunidades</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="css/index.css">
</head>

<body>
  <?php
  require_once "includes/header.php";
  ?>

  <!-- Container 1 -->
  <div class="container1">
    <div class="content fade-in">
      <h1>OPORTUNIDADES PARA TODOS</h1>
      <h2>CONSTRUINDO CARREIRAS DE SUCESSO</h2>
      <p>Na Busca Jobs, conectamos empresas e talentos, oferecendo soluções completas para recrutamento, seleção e desenvolvimento profissional.</p>
      <button class="btn-red" onclick="window.location.href='servico.php'">Nossos Serviços</button>
      <button class="btn-outline-red" onclick="window.location.href='servico.php'">Sobre Nós</button>
      </div>
  </div>

  <!-- Container 2 -->
  <div class="container2">
    <h1 class="fade-in">Parcerias com empresas líderes para transformar carreiras e negócios</h1>
    <div class="services">
      <div onclick="window.location.href='servico.php'" class="service-item fade-in">
        <img src="images/60fa73d72297751c68a185e4ff2a19b1.jpg" alt="Serviço 1">
        <h1>Encontre Talentos</h1>
        <p>Precisa preencher vagas importantes? Nosso banco de talentos tem os melhores profissionais prontos para transformar sua empresa.</p>
      </div>
      <div onclick="window.location.href='servico.php'" class="service-item fade-in">
        <img src="images/OIP (4).jpg" alt="Serviço 2">
        <h1>Descubra Vagas</h1>
        <p>Buscando uma nova oportunidade? Explore vagas exclusivas em empresas de destaque e dê o próximo passo na sua carreira.</p>
      </div>
    </div>
  </div>

  <!-- Container 3 -->
  <div class="container3">
    <div onclick="window.location.href='servico.php'" class="first-div fade-in">
      <h1>Descubra nossos Serviços</h1>
      <p>Oferecemos soluções para recrutamento, seleção, treinamento e consultoria de carreira, garantindo qualidade em cada etapa.</p>
      <button class="btn-transparent">Saiba Mais</button>
    </div>
    <div onclick="window.location.href='servico.php'" class="second-div">
      <div class="icon-box fade-in">
        <i class="fas fa-briefcase"></i>
        <p>Recrutamento</p>
        <p>Selecionamos os melhores profissionais para suas necessidades.</p>
      </div>
      <div onclick="window.location.href='servico.php'" class="icon-box fade-in">
        <i class="fas fa-user-graduate"></i>
        <p>Treinamento</p>
        <p>Capacitação para profissionais e equipes.</p>
      </div>
      <div onclick="window.location.href='servico.php'" class="icon-box fade-in">
        <i class="fas fa-hands-helping"></i>
        <p>Consultoria</p>
        <p>Soluções personalizadas para impulsionar sua empresa.</p>
      </div>
      <div onclick="window.location.href='servico.php'" class="icon-box fade-in">
        <i class="fas fa-chart-bar"></i>
        <p>Gestão de Carreira</p>
        <p>Apoio para planejar e alcançar seus objetivos profissionais.</p>
      </div>
    </div>
  </div>

  <!-- Container 4 -->
  <div class="container4 fade-in">
    <div class="background-overlay">
      <h1>Seu parceiro estratégico para alcançar suas metas de carreira</h1>
      <p>Com anos de experiência, ajudamos empresas e candidatos a construir futuros brilhantes.</p>
    </div>
  </div>

  <!-- Container 5 -->
  <div class="container5 fade-in">
    <h1>Histórias de Sucesso</h1>
    <p>Veja como ajudamos pessoas e empresas a alcançar resultados incríveis.</p>
    <div onclick="window.location.href='servico.php'" class="image-gallery">
      <div class="image-item fade-in">
        <img src="images/OIP (1).jpg" alt="História 1">
        <div class="overlay">Saiba Mais</div>
      </div>
      <div onclick="window.location.href='servico.php'" class="image-item fade-in">
        <img src="images/OIP.jpg" alt="História 2">
        <div class="overlay">Saiba Mais</div>
      </div>
      <div onclick="window.location.href='servico.php'" class="image-item fade-in">
        <img src="images/R.jpg" alt="História 3">
        <div class="overlay">Saiba Mais</div>
      </div>
      <div onclick="window.location.href='servico.php'" class="image-item fade-in">
        <img src="images/pexels-linkedin-2182971 (1).jpg" alt="História 4">
        <div class="overlay">Saiba Mais</div>
      </div>
      <div onclick="window.location.href='servico.php'" class="image-item fade-in">
        <img src="images/OIP (2).jpg" alt="História 5">
        <div class="overlay">Saiba Mais</div>
      </div>
      <div onclick="window.location.href='servico.php'" class="image-item fade-in">
        <img src="images/OIP (3).jpg" alt="História 6">
        <div class="overlay">Saiba Mais</div>
      </div>
    </div>
  </div>

  <?php
  require_once "includes/footer.php";
  ?>

  <script>
    document.addEventListener('DOMContentLoaded', function () {
      const elements = document.querySelectorAll('.fade-in');

      function checkVisibility() {
        const windowHeight = window.innerHeight;
        elements.forEach(element => {
          const elementTop = element.getBoundingClientRect().top;
          if (elementTop < windowHeight - 100) {
            element.classList.add('visible');
          }
        });
      }

      checkVisibility();
      window.addEventListener('scroll', checkVisibility);
    });
  </script>
</body>

</html>
