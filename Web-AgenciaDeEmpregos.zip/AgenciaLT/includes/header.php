<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once "conexao.php";

$loginStatus = isset($_SESSION['logado']) && $_SESSION['logado'] === true;
$nomeUsuario = $_SESSION['nome'] ?? "Usuário";
$emailUsuario = $_SESSION['email'] ?? "";
$foto_usuario = $_SESSION['foto'] ?? 'images/user.png';
$tipoUsuario = $_SESSION['tipo_usuario'] ?? ""; 

if (empty($nomeUsuario) && $loginStatus) {
    $email = $_SESSION['email'] ?? '';

    $conn = mysqli_connect($servidor, $usuario, $senha, $banco, $porta);
    $query = "SELECT nome_usuario, foto_usuario,  tipo_usuario FROM tb_usuario WHERE email_usuario = '$email'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nomeUsuario = $row['nome_usuario'];
        $_SESSION['username'] = $nomeUsuario;
        $foto_usuario = $row['foto_usuario'];
        $tipoUsuario = $row['tipo_usuario'];

        if (empty($foto_usuario)) {
            $foto_usuario = 'assets/images/user.png';
        }
    }
    $sql = "SELECT bio_usuario FROM tb_usuario WHERE email_usuario = '$email'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $bio_usuario = $row['bio_usuario'];
    } else {
        $bio_usuario = "Nenhuma biografia encontrada.";
    }

    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cabeçalho Suave</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/header.css">
</head>
<body>
    <header class="classic-header">
        <div class="container">
            <a href="index.php" class="logo-link">
                <div class="logo">
                    <img src="images/logo.png" alt="Logo">
                    <h1>Busca Jobs</h1>
                </div>
            </a>
            <nav>
                <ul>
                    <li><a href="sobre.php">Sobre</a></li>
                    <li>
                    <a href="<?php echo $tipoUsuario === '0' ? 'servico.php' : ($tipoUsuario === '1' ? 'servico1.php' : 'servico.php'); ?>">Serviços</a>
                    </li>
                    <li><a href="contato.php">Contato</a></li>

                    <?php if ($loginStatus) { ?>
                        <li>
                            <a href="logout.php" id="login-status" class="login-icon">
                                <?php if (!empty($foto_usuario) && file_exists($foto_usuario)) { ?>
                                    <img src="<?php echo $foto_usuario; ?>" alt="Foto de Perfil" class="profile-pic">
                                <?php } else { ?>
                                    <i class="fas fa-user"></i> <!-- Ícone como imagem padrão -->
                                <?php } ?>
                                <?php echo $nomeUsuario; ?>
                            </a>
                        </li>
                    <?php } else { ?>
                        <li><a href="login.php" class="login-icon"><i class="fas fa-user"></i> Login</a></li>
                    <?php } ?>
                </ul>
            </nav>
        </div>
    </header>
</body>
</html>
