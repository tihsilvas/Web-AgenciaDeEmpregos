<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "bd_buscajobs";
$porta = 3306;

$conn = mysqli_connect($servidor, $usuario, $senha, $banco, $porta);

if (!$conn) {
    die("Erro ao conectar com o servidor!");
}
