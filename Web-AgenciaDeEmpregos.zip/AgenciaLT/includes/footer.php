<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer Agência de Empregos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
   <link rel="stylesheet" href="css/footer.css">
</head>
<body>

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 contact-info">
                    <h5>Contato</h5>
                    <p><i class="fas fa-map-marker-alt"></i> Rua Exemplo, 123, Cidade, Estado</p>
                    <p><i class="fas fa-phone-alt"></i> (11) 1234-5678</p>
                    <p><i class="fas fa-envelope"></i> contato@agenciaempregos.com.br</p>
                </div>
                <div class="col-md-4 links">
                    <h5>Links Úteis</h5>
                    <p><a href="#">Sobre Nós</a></p>
                    <p><a href="#">Serviços</a></p>
                    <p><a href="#">Vagas Disponíveis</a></p>
                    <p><a href="#">Contato</a></p>
                </div>
                <div class="col-md-4 social-icons">
                    <h5>Redes Sociais</h5>
                    <a style="margin-left: 0;" href="#" class="fab fa-facebook-f" aria-label="Facebook"></a>
                    <a href="#" class="fab fa-linkedin-in" aria-label="LinkedIn"></a>
                    <a href="#" class="fab fa-instagram" aria-label="Instagram"></a>
                    <br>
                    <p class="copywrite">&copy; 2024 Agência de Empregos. Todos os direitos reservados.</p> 
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
