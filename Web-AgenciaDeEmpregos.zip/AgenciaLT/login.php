<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style>
    * {
      box-sizing: border-box;
    }

    @import url('https://fonts.googleapis.com/css?family=Rubik:400,500&display=swap');

    body {
      font-family: 'Rubik', sans-serif;
      padding: 0;
      margin: 0;
      box-sizing: border-box;
      background-color: #FFFFFF;
      /* Fundo branco */
      color: #333333;
      /* Texto padrão em cinza escuro */
    }

    .container {
      display: flex;
      height: 100vh;
    }

    .left {
      overflow: hidden;
      display: flex;
      flex-wrap: wrap;
      flex-direction: column;
      justify-content: center;
      animation-name: left;
      animation-duration: 1s;
      animation-fill-mode: both;
      animation-delay: 1s;
      width: 50%;
      background-color: #2d3748;
      color: #edf2f7;
      transition: background-size 0.5s ease;
      /* Smooth transition for zoom effect */
    }

    .right {
      flex: 1;
      background-color: #1a202c;
      transition: 5s;
      background-image: url(images/pexels-linkedin-2182971\ \(1\).jpg);
      background-size: cover;
      background-repeat: no-repeat;
      background-position: center;
      transition: background-size 2s ease;
      /* Smooth transition for zoom effect */
    }

    /* Zoom effect on hover */
    .right:hover {
      background-size: 110%;
      /* Adjust the percentage to control the zoom level */
    }

    .header>h2 {
      margin: 0;
      color: #edf2f7;
    }

    .header>h4 {
      margin-top: 10px;
      font-weight: normal;
      font-size: 15px;
      color: rgba(237, 242, 247, 0.7);
    }

    .form {
      max-width: 80%;
      display: flex;
      flex-direction: column;
    }

    .form>p {
      text-align: right;
    }

    .form>p>a {
      color: #d4d4d4;
      font-size: 13px;
      text-decoration: none;
      transition: color 0.3s ease, font-size 0.3s ease;
    }

    .form>p>a:hover {
      color: #bdbdbd;
      font-size: 13.2px;
    }

    .form-field {
      height: 46px;
      padding: 0 16px;
      border: 1px solid #4a5568;
      border-radius: 4px;
      font-family: 'Rubik', sans-serif;
      outline: 0;
      transition: border-color 0.3s ease, background-color 0.3s ease;
      margin-top: 20px;
      background-color: #2d3748;
      color: #edf2f7;
    }

    .form-field:hover {
      border-color: #636c7c;
    }

    .form-field:focus {
      border-color: #636c7c;
    }

    .form>button {
      position: relative;
      padding: 12px 10px;
      border: 1.5px solid #4a5568;
      background-color: #2d3748;
      color: #9b9b9b;
      letter-spacing: 1px;
      font-family: 'Rubik', sans-serif;
      cursor: pointer;
      overflow: hidden;
      transition: color 0.5s ease, background-color 0.5s ease;
      border-radius: 3px;
      outline: none;
    }

    .form>button::before,
    .form>button::after {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      border-radius: 3px;
      transition: transform 0.5s ease, width 0.5s ease, height 0.5s ease;
      transform: scale(0);
      z-index: 0;
    }

    .form>button:hover {
      background-color: #4a5568;
      color: #edf2f7;
      transform: scale(0);
    }

    .form>button span {
      position: relative;
      z-index: 1;
    }

    .animation {
      animation-name: move;
      animation-duration: .4s;
      animation-fill-mode: both;
      animation-delay: 2s;
    }

    .a1 {
      animation-delay: 2s;
    }

    .a2 {
      animation-delay: 2.1s;
    }

    .a3 {
      animation-delay: 2.2s;
    }

    .a4 {
      animation-delay: 2.3s;
    }

    .a5 {
      animation-delay: 2.4s;
    }

    .a6 {
      animation-delay: 2.5s;
    }

    .a7 {
      animation-delay: 2.6s;
    }

    .a8 {
      animation-delay: 2.7s;
    }

    @keyframes move {
      0% {
        opacity: 0;
        visibility: hidden;
        transform: translateY(-40px);
      }

      100% {
        opacity: 1;
        visibility: visible;
        transform: translateY(0);
      }
    }

    @keyframes left {
      0% {
        opacity: 0;
        width: 0;
      }

      100% {
        opacity: 1;
        padding: 20px 40px;
        width: 440px;
      }
    }

    .hidden {
      display: none;
    }

    .error {
      color: #f56565;
      /* Vermelho claro para erros */
      font-size: 12px;
      margin-top: 5px;
    }

    /* Estilos para o ícone de voltar */
    .back-icon {
      position: absolute;
      top: 3vh;
      left: 7vh;
      font-size: 3.7vh;
      color: #fff;
      cursor: pointer;
      transition: color 0.3s ease, transform 0.3s ease;
      /* Transição suave para a cor e transformação */
    }

    /* Efeito de hover para o ícone de voltar */
    .back-icon:hover {
      color: #919191;
      transform: scale(1.1);
      /* Efeito de ampliação ao passar o mouse */
    }
  </style>
  <title>Login / Cadastro</title>
</head>

<body>
  <div class="container">
    <div class="left">
      <a href="index.php" class="back-icon"><i class="fas fa-arrow-left"></i></a>
      
      <form id="login-form" class="form" action="scripts/validar.php" method="POST">
        <div class="header">
          <h2 class="animation a1">Bem vindo de Volta</h2>
          <h4 class="animation a2">Conecte-se à sua conta utilizando Email e Senha</h4>
        </div>
        <input type="email" id="login-email" class="form-field animation a3" name="txt_email" placeholder="Endereço de Email" name="email">
        <div id="login-email-error" class="error"></div>
        <input type="password" id="login-password" class="form-field animation a4" placeholder="Senha" name="txt_senha">
        <div id="login-password-error" class="error"></div>
        <p class="animation a5"><a href="scripts/recuperacao_senha/inserir_email.html">Esqueci a Senha</a></p>
        <button class="animation a6" onclick="validateLogin()"><span>LOGIN</span></button>
        <p class="animation a7"><a href="#" onclick="showSignup()">Crie uma Conta</a></p>
      </form>

      <form id="signup-form" class="form hidden" action="scripts/processar.php" method="POST">
        <div class="header">
          <h2 class="animation a1">Crie uma Conta</h2>
          <h4 class="animation a2">Preencha o formulário abaixo para criar uma conta</h4>
        </div>
        <input type="text" id="signup-name" class="form-field animation a3" placeholder="Nome completo" name="txt_nome">
        <div id="signup-name-error" class="error"></div>
        <input type="email" id="signup-email" class="form-field animation a4" placeholder="Endereço de Email" name="txt_email">
        <div id="signup-email-error" class="error"></div>
        <input type="password" id="signup-password" class="form-field animation a5" placeholder="Senha" name="txt_senha">
        <div id="signup-password-error" class="error"></div>
        <input type="password" id="signup-confirm-password" class="form-field animation a6" placeholder="Confirme a Senha" name="confSenha">
        <div id="signup-confirm-password-error" class="error"></div>
        <select id="signup-type" class="form-field animation a7" name="txt_tipo_usuario">
          <option value="0">Pessoa Física</option>
          <option value="1">Pessoa Jurídica</option>
        </select>
        <div id="signup-type-error" class="error"></div>
        <p class="animation a7"><a href="#" onclick="showLogin()">Já possui uma conta? Faça Login</a></p>
        <button class="animation a8" onclick="validateSignup()"><span>Cadastre-se</span></button>
      </form>
    </div>
    <div class="right"></div>
  </div>

  <script>
    function showSignup() {
      document.getElementById('login-form').classList.add('hidden');
      document.getElementById('signup-form').classList.remove('hidden');
    }

    function showLogin() {
      document.getElementById('signup-form').classList.add('hidden');
      document.getElementById('login-form').classList.remove('hidden');
    }

    function validateLogin(event) {
      let isValid = true;
      const email = document.getElementById('login-email');
      const password = document.getElementById('login-password');
      const emailError = document.getElementById('login-email-error');
      const passwordError = document.getElementById('login-password-error');

      // Clear previous errors
      emailError.textContent = '';
      passwordError.textContent = '';

      if (!email.value) {
        emailError.textContent = 'Email é obrigatório';
        isValid = false;
      } else if (!/\S+@\S+\.\S+/.test(email.value)) {
        emailError.textContent = 'Formato de email inválido';
        isValid = false;
      }

      if (!password.value) {
        passwordError.textContent = 'Senha é obrigatória';
        isValid = false;
      }

      if (!isValid) {
        event.preventDefault(); // Impede o envio do formulário se inválido
      }
    }

    function validateSignup(event) {
      let isValid = true;
      const name = document.getElementById('signup-name');
      const email = document.getElementById('signup-email');
      const password = document.getElementById('signup-password');
      const confirmPassword = document.getElementById('signup-confirm-password');
      const nameError = document.getElementById('signup-name-error');
      const emailError = document.getElementById('signup-email-error');
      const passwordError = document.getElementById('signup-password-error');
      const confirmPasswordError = document.getElementById('signup-confirm-password-error');
      const userTypeError = document.getElementById('signup-type-error');


      // Clear previous errors
      nameError.textContent = '';
      emailError.textContent = '';
      passwordError.textContent = '';
      confirmPasswordError.textContent = '';
      userTypeError.textContent = '';


      if (!name.value) {
        nameError.textContent = 'Nome completo é obrigatório';
        isValid = false;
      }

      if (!email.value) {
        emailError.textContent = 'Email é obrigatório';
        isValid = false;
      } else if (!/\S+@\S+\.\S+/.test(email.value)) {
        emailError.textContent = 'Formato de email inválido';
        isValid = false;
      }

      if (!password.value) {
        passwordError.textContent = 'Senha é obrigatória';
        isValid = false;
      }

      if (password.value !== confirmPassword.value) {
        confirmPasswordError.textContent = 'As senhas não coincidem';
        isValid = false;
      }

      if (!userType.value) {
        userTypeError.textContent = 'Tipo de usuário é obrigatório';
        isValid = false;
      }

      if (!isValid) {
        event.preventDefault(); // Impede o envio do formulário se inválido
      }
    }

    // Adiciona os eventos de validação aos formulários
    document.getElementById('login-form').addEventListener('submit', validateLogin);
    document.getElementById('signup-form').addEventListener('submit', validateSignup);
  </script>
</body>

</html>