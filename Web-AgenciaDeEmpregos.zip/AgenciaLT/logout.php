<?php
session_start(); // Inicia a sessão

// Verifica se o usuário está logado
if (isset($_SESSION['logado']) && $_SESSION['logado'] === true) {
    // Destrói todas as variáveis da sessão
    $_SESSION = []; // Limpa a sessão
    
    // Destrói a sessão
    session_destroy();
    
    // Redireciona para a página de login ou página inicial
    header('Location: index.php'); // Altere para a página desejada
    exit();
} else {
    // Se não estiver logado, redireciona para a página inicial
    header('Location: index.php'); // Altere para a página desejada
    exit();
}
