<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre Nós</title>
    <!-- Importar o Bootstrap e Font Awesome -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Importar Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="css/sobre.css">
</head>

<body>
    <?php
    require_once "includes/header.php"
    ?>
    <div class="first-part">
        <div class="line-red"></div>
        <h1>Sobre Nós</h1>
    </div>

    <div class="info-section">
        <p>Home / Sobre Nós</p>
    </div>

    <div class="second-part container">
        <div class="row">
            <div class="col-md-4">
                <i class="fas fa-briefcase icons-height"></i>
                <h2>Missão</h2>
                <p>Nossa missão é oferecer soluções inovadoras para promover uma vida mais saudável e equilibrada. Buscamos melhorar a qualidade de vida das pessoas através da tecnologia, proporcionando ferramentas que incentivem bons hábitos e o bem-estar geral.</p>
            </div>
            <div class="col-md-4">
                <i class="fas fa-eye icons-height"></i>
                <h2>Visão</h2>
                <p>Queremos ser líderes globais em tecnologia de saúde e bem-estar, ajudando milhões de pessoas a adotar estilos de vida saudáveis. Estamos constantemente inovando para fornecer as melhores soluções e impactar positivamente a vida de nossos usuários.</p>
            </div>
            <div class="col-md-4">
                <i class="fas fa-heart icons-height"></i>
                <h2>Valores</h2>
                <p>Valorizamos a ética, inovação, sustentabilidade e o compromisso com a saúde e bem-estar. Nosso objetivo é sempre manter a integridade e a excelência em tudo o que fazemos, priorizando as necessidades de nossos clientes.</p>
            </div>
        </div>
    </div>

    <div class="chart-container">
        <h3>Crescimento de Usuários</h3>
        <canvas id="lineChart"></canvas>
    </div>

    <div class="chart-container">
        <h3>Distribuição de Departamentos</h3>
        <canvas id="barChart"></canvas>
    </div>

    <?php
    require_once "includes/footer.php"
    ?>

    <!-- Scripts do Bootstrap e Font Awesome -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Script para Chart.js -->
    <script>
        // Gráfico de Linhas - Crescimento de Usuários
        const ctxLine = document.getElementById('lineChart').getContext('2d');
        const lineChart = new Chart(ctxLine, {
            type: 'line',
            data: {
                labels: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho'],
                datasets: [{
                    label: 'Usuários',
                    data: [500, 700, 900, 1200, 1500, 1800],
                    borderColor: 'rgba(121, 0, 0, 1)',
                    backgroundColor: 'rgba(121, 0, 0, 0.2)',
                    fill: true,
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Crescimento de Usuários nos Últimos Meses'
                    }
                }
            }
        });

        // Gráfico de Barras - Distribuição de Departamentos
        const ctxBar = document.getElementById('barChart').getContext('2d');
        const barChart = new Chart(ctxBar, {
            type: 'bar',
            data: {
                labels: ['Desenvolvimento', 'Marketing', 'Suporte', 'Financeiro', 'RH'],
                datasets: [{
                    label: 'Funcionários',
                    data: [50, 30, 20, 15, 10],
                    backgroundColor: 'rgba(121, 0, 0, 0.2)',
                    borderColor: 'rgba(121, 0, 0, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Distribuição de Funcionários por Departamento'
                    }
                }
            }
        });
    </script>
</body>

</html>
