<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Inicial - Agência de Empregos e Estágios</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500&display=swap">
    <link rel="stylesheet" href="css/servico.css">
</head>

<body>
<?php require_once "includes/header.php"; ?>

<div class="hero">
    <div class="selector-container">
        <select id="state-select">
            <option value="">Selecione o Estado</option>
            <option value="sp">São Paulo</option>
            <option value="rj">Rio de Janeiro</option>
            <option value="mg">Minas Gerais</option>
        </select>

        <select id="city-select" disabled>
            <option value="">Selecione a Cidade</option>
        </select>
        <button id="search-btn">
            <span class="material-icons">search</span>
        </button>
    </div>
</div>

<div class="info-section">
    <h1>BUSCANDO UMA VAGA DE EMPREGO?</h1>
    <h2>Conheça nossas vagas disponíveis e se candidate neste exato momento</h2>
</div>

<!-- Mensagem de sucesso ou erro -->
<div id="notification" class="notification" style="display: none;">
    <?php if (isset($_SESSION['mensagem_sucesso'])): ?>
        <div class="alert success">
            <?php
                echo $_SESSION['mensagem_sucesso'];
                unset($_SESSION['mensagem_sucesso']);
            ?>
        </div>
    <?php elseif (isset($_SESSION['mensagem_erro'])): ?>
        <div class="alert error">
            <?php
                echo $_SESSION['mensagem_erro'];
                unset($_SESSION['mensagem_erro']);
            ?>
        </div>
    <?php endif; ?>
</div>

<div class="content">
    <div class="job-list">
        <h1>Vagas de Empregos</h1>
        <?php
        // Fetch job vacancies
        $stmt = $conn->prepare("SELECT * FROM tb_vaga");
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="job-item" data-job-id="' . htmlspecialchars($row['id_vaga']) . '">';
                echo '<img src="images/logo.png" alt="' . htmlspecialchars($row['titulo']) . '">';
                echo '<div>';
                echo '<h3>' . htmlspecialchars($row['titulo']) . '</h3>';
                echo '<p>Localização: ' . htmlspecialchars($row['localizacao']) . '</p>';
                echo '<form action="candidatar.php" method="POST">';
                echo '<input type="hidden" name="id_vaga" value="' . htmlspecialchars($row['id_vaga']) . '">';
                echo '<button type="submit" class="contratar-btn">Contratar Vaga</button>';
                echo '</form>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo '<p>Não há vagas disponíveis no momento.</p>';
        }
        ?>
    </div>
</div>

<?php require_once "includes/footer.php"; ?>

<script>
    const cityOptions = {
        sp: ["São Paulo", "Campinas", "Santos", "São Bernardo do Campo", "Sorocaba"],
        rj: ["Rio de Janeiro", "Niterói", "Petropolis", "Cabo Frio", "Búzios"],
        mg: ["Belo Horizonte", "Uberlândia", "Juiz de Fora", "Contagem", "Betim"]
    };

    document.getElementById('state-select').addEventListener('change', function() {
        const state = this.value;
        const citySelect = document.getElementById('city-select');

        citySelect.innerHTML = '<option value="">Selecione a Cidade</option>';
        if (state && cityOptions[state]) {
            cityOptions[state].forEach(city => {
                const option = document.createElement('option');
                option.value = city.toLowerCase().replace(/ /g, '-');
                option.textContent = city;
                citySelect.appendChild(option);
            });
            citySelect.disabled = false;
        } else {
            citySelect.disabled = true;
        }
    });

    // Exibe a notificação se houver mensagem
    document.addEventListener("DOMContentLoaded", function() {
        const notification = document.getElementById('notification');
        if (notification.innerHTML.trim() !== "") {
            notification.style.display = "block";
            setTimeout(() => {
                notification.style.opacity = "0";
                setTimeout(() => {
                    notification.style.display = "none";
                }, 500); // Espera o fade-out antes de esconder
            }, 3000); // Exibe por 3 segundos
        }
    });
</script>
</body>
</html>
